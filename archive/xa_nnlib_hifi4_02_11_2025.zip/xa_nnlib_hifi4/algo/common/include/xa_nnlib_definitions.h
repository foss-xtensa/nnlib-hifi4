/*******************************************************************************
* Copyright (c) 2018-2025 Cadence Design Systems, Inc.
*
* Permission is hereby granted, free of charge, to any person obtaining
* a copy of this software and associated documentation files (the
* "Software"), to use this Software with Cadence processor cores only and
* not with any other processors and platforms, subject to
* the following conditions:
*
* The above copyright notice and this permission notice shall be included
* in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
* MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
* IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
* CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
* TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
* SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

******************************************************************************/


#ifndef __XA_NNLIB_DEFINITIONS_H__
#define __XA_NNLIB_DEFINITIONS_H__

#include "xa_api_defs.h"

/* Identification Strings */
#ifdef hifi5
#define LIBNAME "HiFi5 Neural Network Library"
#define LIBVERSION "5.0.0"

#define LIB_APIVERSION_MAJOR 2
#define LIB_APIVERSION_MINOR 0

#else /* #ifdef hifi5 */
#define LIBNAME "HiFi Neural Network Library"
#define LIBVERSION "5.0.0"

#define LIB_APIVERSION_MAJOR 2
#define LIB_APIVERSION_MINOR 0

#endif /* #ifdef hifi5 */

#if LIB_APIVERSION_MAJOR != XA_APIVERSION_MAJOR || \
LIB_APIVERSION_MINOR != XA_APIVERSION_MINOR
//#error "Version Mismatch"
#endif

#define LIB_APIVERSION              XA_MAKE_VERSION_STR(\
                                    LIB_APIVERSION_MAJOR, \
                                    LIB_APIVERSION_MINOR)

#endif /* __XA_NNLIB_DEFINITIONS_H__ */
